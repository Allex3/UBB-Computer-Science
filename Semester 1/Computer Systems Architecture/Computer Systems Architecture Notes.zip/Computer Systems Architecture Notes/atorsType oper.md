
They specify the types of some expressions or operands stored in memory. Their syntax is: **type expression**, where the specifier is one of the following: **BYTE, WORD, DWORD, QWORD, TWORD**

- *expression* is treated temporarily, as having a *type* size of without destructively modifying its initial value.