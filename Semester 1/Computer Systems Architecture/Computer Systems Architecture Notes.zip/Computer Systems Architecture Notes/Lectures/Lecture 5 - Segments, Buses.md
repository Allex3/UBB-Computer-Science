
#### [[BIU (Bus Interface Unit) Registers]]
### [[Memory Segments (and addresses)]] - ALL THE THEORY