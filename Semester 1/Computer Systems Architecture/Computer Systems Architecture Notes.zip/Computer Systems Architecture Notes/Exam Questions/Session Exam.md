
- Here are the next lines of code, what is their output 