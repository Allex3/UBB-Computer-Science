
LHS = address specification value (something that can be assigned TO)
RHS = anything