>[!important] 4 sequences of instructions 
>- Overflow yes/no
>- OF = ? CF = ?
>- Which of those 4 operations produce different results in OF/CF?
>- In which situations does the multiplication produce different values for OF/CF

1 + 1 = 0
0 + 0 = 1
1 - 0 = 0
0 - 1 = 1

>[!info] Division overflow = run-time error

